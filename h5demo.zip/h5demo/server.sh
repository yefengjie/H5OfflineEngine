#! /bin/bash
echo 'please wait...'
python -m http.server 8080
echo 'start server at http://localhost:8080/'
